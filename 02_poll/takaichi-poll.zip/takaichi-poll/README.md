# Takaichi Cabinet Approval Poll (Cloudflare Worker + KV)

A single Cloudflare Worker that serves a two-choice poll page (支持する /
支持しない), stores votes in Workers KV, limits each visitor to one vote per
calendar week, and renders a public weekly chart of the results — no
separate backend or database needed.

## How it works

- **Frontend + API in one Worker.** `src/index.js` serves the HTML page at
  `GET /` and exposes `GET /api/status`, `POST /api/vote`, `GET /api/results`.
- **One-vote-per-week enforcement, two identity layers.** The primary check
  is a random id in a first-party `HttpOnly` cookie (set on first visit,
  ~400 days), because that survives the visitor's public IP changing —
  common on Japanese home internet, where a PPPoE reconnect can reassign the
  IP overnight and previously let people vote again the next day just from
  that. When there's no cookie (blocked/cleared), it falls back to a salted
  SHA-256 hash of IP + User-Agent, so a cleared cookie alone still doesn't
  bypass the cap as long as the connection is unchanged. Votes are written to
  `vote:<weekId>:<voterId>` (tallied) plus a lightweight
  `voteix:<weekId>:<ipUaHash>` index (not tallied, different prefix).
  `weekId` is an ISO week computed in JST (e.g. `2026-W38`) — because the
  week is baked into the key, voting again simply becomes possible once a
  new week starts, nothing needs to expire or be reset.
- **Weekly aggregation without a counter.** The vote's choice is stored both
  as the KV value and as `metadata` on the primary key. `GET /api/results`
  lists all `vote:*` keys and tallies `metadata.choice` per week — this reads
  metadata only (no per-key `get()` calls), so it stays cheap even with many
  votes, and there's no read-modify-write counter that could race under
  concurrent voting.
- **Public results.** Anyone who opens the page sees the current week's
  totals and a line chart of the support rate over time (Chart.js, loaded
  from cdnjs with a jsdelivr fallback).

### Known limitations (by design, for a casual public poll)

- Deliberately clearing the cookie *and* getting a new IP (e.g. a VPN) still
  bypasses the cap. This design stops casual/accidental repeat voting and
  ordinary IP churn; it is not forensically strong against someone willing to
  rotate IPs by hand. Cloudflare Turnstile or gating votes behind "Sign in
  with X" would raise the bar further if that becomes a real concern.
- Workers KV is eventually consistent, so under very heavy simultaneous
  traffic a handful of duplicate votes are theoretically possible.
- This is a self-selected, informal poll of whoever clicks the link — not a
  scientifically representative survey. Say so wherever you share it (the
  page already includes a disclaimer footer).

## Prerequisites

- A Cloudflare account (free tier is enough).
- Node.js installed locally.

`package.json` here only pulls in `wrangler` itself (as a `devDependency`) —
there is no framework, no build step, no other packages. Run this once in
the `takaichi-poll` folder before anything else:

```
npm install
```

That installs Wrangler locally into `node_modules/`, so every command below
can be run either as `npx wrangler ...` or via the `npm run` scripts defined
in `package.json` (`npm run dev`, `npm run deploy`). If you'd rather have
`wrangler` available globally instead, `npm install -g wrangler` works too
and you can drop the `npx`/`npm run` prefix.

## Deploy

1. **Log in to Cloudflare:**
   ```
   npx wrangler login
   ```

2. **Create the KV namespace:**
   ```
   npx wrangler kv namespace create POLL_KV
   ```
   This prints an `id`. Copy it into `wrangler.toml`, replacing
   `REPLACE_WITH_YOUR_KV_NAMESPACE_ID`.

   (Optional, for local dev with `wrangler dev`):
   ```
   npx wrangler kv namespace create POLL_KV --preview
   ```
   and paste that id into `preview_id` in `wrangler.toml`.

3. **Set the voter-hash salt as a secret** (any random string; it just makes
   the fingerprint harder to precompute — it doesn't need to be memorable):
   ```
   npx wrangler secret put VOTER_SALT
   ```

4. **Deploy:**
   ```
   npm run deploy
   ```
   (equivalent to `npx wrangler deploy`)
   Wrangler prints the live URL, something like:
   ```
   https://takaichi-cabinet-poll.<your-subdomain>.workers.dev
   ```
   That URL is both the voting page and the public results page — nothing
   else to host.

5. *(Optional)* Attach a custom domain from the Cloudflare dashboard
   (Workers & Pages → your worker → Settings → Triggers → Custom Domains) if
   you'd rather share a branded URL.

## Posting to X

Once you have the deployed URL, post it from your own X account (this
session has no X/Twitter connection, so posting has to be done manually).
Draft text:

> 【アンケート】高市内閣を支持しますか？
> 投票はこちら → <あなたのURL>
> ※投票はおひとり様1週間に1回までです
> #高市内閣 #支持率調査

Feel free to re-post the same link weekly — the chart keeps accumulating
history automatically, one bar per week.

## Local development

```
npm run dev
```
This runs the Worker locally against the preview KV namespace, at
`http://localhost:8787`.
