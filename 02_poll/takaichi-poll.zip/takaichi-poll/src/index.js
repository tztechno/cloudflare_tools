// Takaichi Cabinet approval poll — single-file Cloudflare Worker.
//
// Routes:
//   GET  /             -> poll page (vote buttons + live weekly chart)
//   GET  /api/status   -> tells the caller whether they already voted this week
//   POST /api/vote     -> records a vote ({ choice: "support" | "against" })
//   GET  /api/results  -> weekly aggregated tallies, used to draw the chart
//
// Storage design (Workers KV, binding: POLL_KV):
//   Each vote is written to a primary key: vote:<weekId>:<voterId>
//   - weekId is an ISO-8601 week computed in JST (e.g. "2026-W38").
//     Because the week is baked into the key, a voter can vote again once a
//     new week starts without any TTL/expiry bookkeeping.
//   - voterId identifies the visitor. It prefers a random id stored in a
//     first-party HttpOnly cookie (set on first visit, ~400 days), because
//     that survives the visitor's public IP changing — common on Japanese
//     home internet, where PPPoE reconnects can reassign the IP overnight
//     and previously let people vote again the very next day. When no
//     cookie is present (blocked/cleared), it falls back to a salted
//     IP+User-Agent hash, same as before.
//   - A second, lightweight index key voteix:<weekId>:<ipUaHash> is always
//     written too (any prefix other than "vote:" so it's excluded from
//     tallying). It means a cleared cookie alone still doesn't bypass the
//     cap as long as the IP+UA is unchanged — the original behaviour is
//     preserved as a fallback layer rather than replaced.
//   - The vote's choice is stored both as the value and as put() metadata
//     on the primary key. list() returns metadata without extra reads, so
//     tallying a week is a single (paginated) list() call instead of N
//     individual get() calls.
//
// Known limitations (documented here on purpose):
//   - Workers KV is eventually consistent, so under very heavy concurrent
//     traffic a handful of duplicate votes from the same person are possible.
//     For a casual public opinion poll this tradeoff is fine.
//   - Deliberately clearing cookies AND getting a new IP (e.g. via VPN) still
//     bypasses the cap. This deters casual/accidental repeat voting and
//     ordinary IP churn; it is not forensically strong against a determined
//     attacker willing to rotate IPs by hand.
//   - This is an informal, self-selected sample (X/Twitter followers who
//     click through), not a scientific poll. Say so on the page.

// Two independent CDNs are tried in order (see loadScriptWithFallback in the
// page's inline script below). If a visitor's network blocks one CDN, or a
// pinned version has been pruned from it, the page falls back to the other
// instead of silently failing to draw the chart. Voting itself never depends
// on this — only the chart rendering does.
const CHART_JS_PRIMARY_SRC = "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.5.1/chart.umd.min.js";
const CHART_JS_FALLBACK_SRC = "https://cdn.jsdelivr.net/npm/chart.js@4.5.1/dist/chart.umd.min.js";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const { cookieId, setCookieHeader } = getOrIssueVoterCookie(request);

    let response;
    if (request.method === "GET" && url.pathname === "/") {
      response = new Response(renderHTML(), {
        headers: { "content-type": "text/html; charset=UTF-8" },
      });
    } else if (request.method === "GET" && url.pathname === "/api/status") {
      response = await handleStatus(request, env, cookieId);
    } else if (request.method === "POST" && url.pathname === "/api/vote") {
      response = await handleVote(request, env, cookieId);
    } else if (request.method === "GET" && url.pathname === "/api/results") {
      response = await handleResults(env);
    } else {
      response = new Response("Not Found", { status: 404 });
    }

    // Issue the voter cookie on whichever response goes out, the first time
    // a visitor is seen (subsequent requests already carry it, so this is a
    // one-time header add per visitor).
    if (setCookieHeader) {
      response = new Response(response.body, response);
      response.headers.append("Set-Cookie", setCookieHeader);
    }

    return response;
  },
};

// ---------------------------------------------------------------------------
// Week / fingerprint helpers
// ---------------------------------------------------------------------------

// Compute an ISO-8601 week id (Mon-Sun weeks, e.g. "2026-W38") as seen from
// Japan Standard Time. Workers always run with an internal UTC clock, so we
// shift the timestamp by +9h and then read it back with the UTC-* accessors
// as if that shifted instant were "local" JST time.
function getWeekId(now = new Date()) {
  const jst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
  const d = new Date(Date.UTC(jst.getUTCFullYear(), jst.getUTCMonth(), jst.getUTCDate()));

  // ISO week: shift to the Thursday of the same week, then count weeks
  // from the Thursday-anchored start of that ISO year.
  const dayNum = d.getUTCDay() || 7; // Sunday (0) -> 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);

  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

// Inverse of getWeekId: given "YYYY-Www", return the Monday of that ISO
// week as a "YYYY-MM-DD" date string. Used to label the results chart with
// real calendar dates instead of raw week ids.
function getWeekStartDate(weekId) {
  const [yearStr, weekStr] = weekId.split("-W");
  const year = Number(yearStr);
  const week = Number(weekStr);

  // Jan 4th is always in ISO week 1; find that week's Monday, then add
  // (week - 1) full weeks to reach the target week's Monday.
  const jan4 = new Date(Date.UTC(year, 0, 4));
  const jan4Day = jan4.getUTCDay() || 7; // Sunday (0) -> 7
  const week1Monday = new Date(jan4);
  week1Monday.setUTCDate(jan4.getUTCDate() - (jan4Day - 1));

  const monday = new Date(week1Monday);
  monday.setUTCDate(week1Monday.getUTCDate() + (week - 1) * 7);

  const mm = String(monday.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(monday.getUTCDate()).padStart(2, "0");
  return `${monday.getUTCFullYear()}-${mm}-${dd}`;
}

// --- Voter cookie (primary identity; survives the visitor's IP changing) ---

const VOTER_COOKIE_NAME = "voter_id";
// ~400 days: the practical cap most browsers enforce on Max-Age anyway.
const VOTER_COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 400;

function parseCookies(request) {
  const header = request.headers.get("Cookie") || "";
  const out = {};
  for (const part of header.split(";")) {
    const idx = part.indexOf("=");
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (key) out[key] = value;
  }
  return out;
}

// Reuse the visitor's existing voter_id cookie if the request has one;
// otherwise mint a fresh one and return a Set-Cookie header to attach to
// the response. HttpOnly because the frontend JS never needs to read it —
// same-origin fetch() already sends cookies automatically.
function getOrIssueVoterCookie(request) {
  const existing = parseCookies(request)[VOTER_COOKIE_NAME];
  if (existing) {
    return { cookieId: existing, setCookieHeader: null };
  }
  const cookieId = crypto.randomUUID();
  const setCookieHeader =
    `${VOTER_COOKIE_NAME}=${cookieId}; Path=/; Max-Age=${VOTER_COOKIE_MAX_AGE_SECONDS}; ` +
    `HttpOnly; Secure; SameSite=Lax`;
  return { cookieId, setCookieHeader };
}

async function hashVoter(request, env) {
  const ip = request.headers.get("CF-Connecting-IP") || "unknown-ip";
  const ua = request.headers.get("User-Agent") || "unknown-ua";
  // VOTER_SALT is a secret set with `wrangler secret put VOTER_SALT`.
  // It just makes the fingerprint harder to precompute/guess; it is not
  // meant to be a strong anti-abuse measure on its own.
  const salt = env.VOTER_SALT || "change-me-please";
  const data = new TextEncoder().encode(`${ip}|${ua}|${salt}`);
  const digestBuf = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digestBuf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function jsonResponse(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=UTF-8" },
  });
}

// ---------------------------------------------------------------------------
// API handlers
// ---------------------------------------------------------------------------

// Look up whether this visitor has already voted this week, checking both
// identity layers: the cookie (primary, survives IP changes) and the
// IP+User-Agent index (fallback, catches a cleared cookie on an unchanged
// connection). Returns the choice string if found, otherwise null.
async function lookupExistingVote(env, weekId, cookieId, ipUaHash) {
  const byCookie = cookieId ? await env.POLL_KV.get(`vote:${weekId}:${cookieId}`) : null;
  if (byCookie !== null) return byCookie;
  return env.POLL_KV.get(`voteix:${weekId}:${ipUaHash}`);
}

async function handleStatus(request, env, cookieId) {
  const weekId = getWeekId();
  const ipUaHash = await hashVoter(request, env);
  const existing = await lookupExistingVote(env, weekId, cookieId, ipUaHash);
  return jsonResponse({ weekId, alreadyVoted: existing !== null, choice: existing });
}

async function handleVote(request, env, cookieId) {
  let body;
  try {
    body = await request.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }

  const choice = body && body.choice;
  if (choice !== "support" && choice !== "against") {
    return jsonResponse({ error: "invalid_choice" }, 400);
  }

  const weekId = getWeekId();
  const ipUaHash = await hashVoter(request, env);

  const existing = await lookupExistingVote(env, weekId, cookieId, ipUaHash);
  if (existing !== null) {
    return jsonResponse({ ok: false, alreadyVoted: true, weekId, choice: existing }, 409);
  }

  // Primary record, used for tallying: keyed by the cookie id when we have
  // one (survives the visitor's IP changing overnight), falling back to the
  // IP+UA hash when there's no cookie at all.
  const voterId = cookieId || ipUaHash;
  await env.POLL_KV.put(`vote:${weekId}:${voterId}`, choice, { metadata: { choice } });

  // Secondary index, always keyed by IP+UA (different prefix, so it's not
  // double-counted by handleResults' "vote:" listing). This is what still
  // catches a deliberately-cleared cookie as long as the IP+UA is unchanged.
  await env.POLL_KV.put(`voteix:${weekId}:${ipUaHash}`, choice);

  return jsonResponse({ ok: true, weekId, choice });
}

async function handleResults(env) {
  const weekly = {}; // weekId -> { support, against }
  let cursor;

  do {
    const page = await env.POLL_KV.list({ prefix: "vote:", cursor, limit: 1000 });

    for (const k of page.keys) {
      // Key shape: vote:<weekId>:<voterHash> — weekId itself has no colon.
      const parts = k.name.split(":");
      const weekId = parts[1];
      const choice = k.metadata && k.metadata.choice;

      if (!weekly[weekId]) weekly[weekId] = { support: 0, against: 0 };
      if (choice === "support") weekly[weekId].support++;
      else if (choice === "against") weekly[weekId].against++;
    }

    cursor = page.list_complete ? undefined : page.cursor;
  } while (cursor);

  const weeks = Object.keys(weekly)
    .sort()
    .map((week) => {
      const { support, against } = weekly[week];
      const total = support + against;
      return {
        week,
        weekStart: getWeekStartDate(week), // "YYYY-MM-DD", Monday of that week (JST)
        support,
        against,
        total,
        supportRate: total > 0 ? Math.round((support / total) * 1000) / 10 : null, // %, 1 decimal
      };
    });

  return jsonResponse({ weeks, currentWeek: getWeekId() });
}

// ---------------------------------------------------------------------------
// HTML page (self-contained: inline CSS/JS, Chart.js loaded from cdnjs)
// ---------------------------------------------------------------------------

function renderHTML() {
  return `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>高市内閣 支持率アンケート</title>
<meta property="og:title" content="高市内閣 支持率アンケート">
<meta property="og:description" content="支持する／支持しないの2択で投票できます。1人1週間に1票までです。">
<meta property="og:type" content="website">
<style>
  :root {
    --support: #2e7d32;
    --against: #c62828;
    --bg: #f5f6f8;
    --card: #ffffff;
    --text: #1f2430;
    --muted: #6b7280;
    --border: #e3e5ea;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", "Yu Gothic", sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
    justify-content: center;
    padding: 24px 16px 64px;
  }
  .wrap { width: 100%; max-width: 640px; }
  h1 { font-size: 22px; margin: 0 0 4px; }
  .sub { color: var(--muted); font-size: 13px; margin: 0 0 20px; line-height: 1.6; }
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 16px;
  }
  .buttons { display: flex; gap: 12px; margin-top: 8px; }
  button.vote-btn {
    flex: 1;
    padding: 16px 8px;
    font-size: 16px;
    font-weight: 700;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    color: white;
    transition: opacity 0.15s;
  }
  button.vote-btn:disabled { opacity: 0.5; cursor: default; }
  button.support { background: var(--support); }
  button.against { background: var(--against); }
  #message {
    margin-top: 14px;
    font-size: 14px;
    min-height: 20px;
    color: var(--muted);
  }
  .summary { display: flex; gap: 16px; margin-top: 16px; }
  .summary .stat { flex: 1; text-align: center; }
  .summary .stat .num { font-size: 24px; font-weight: 700; }
  .summary .stat.support .num { color: var(--support); }
  .summary .stat.against .num { color: var(--against); }
  .summary .stat .label { font-size: 12px; color: var(--muted); }
  canvas { max-width: 100%; }
  .disclaimer { font-size: 12px; color: var(--muted); line-height: 1.7; margin-top: 24px; }
</style>
</head>
<body>
<div class="wrap">
  <h1>高市内閣 支持率アンケート</h1>
  <p class="sub">
    高市内閣を支持しますか？ 「支持する」「支持しない」のどちらかに投票してください。<br>
    ご投票は、お一人につき1週間に1回までです。
  </p>

  <div class="card">
    <div class="buttons">
      <button id="btn-support" class="vote-btn support">支持する</button>
      <button id="btn-against" class="vote-btn against">支持しない</button>
    </div>
    <div id="message"></div>
    <div class="summary" id="summary" style="display:none;">
      <div class="stat support">
        <div class="num" id="summary-support">-</div>
        <div class="label">支持する（今週）</div>
      </div>
      <div class="stat against">
        <div class="num" id="summary-against">-</div>
        <div class="label">支持しない（今週）</div>
      </div>
    </div>
  </div>

  <div class="card">
    <canvas id="chart" height="220"></canvas>
  </div>

  <p class="disclaimer">
    ※ このアンケートは個人が実施する非公式なインターネット投票です。回答者はSNS上の閲覧者に限られるため、
    統計的に社会全体の縮図とはなりません。参考情報としてご覧ください。<br>
    ※ 二重投票防止のため、簡易的な識別（IPアドレス等）を用いて1週間に1回までに制限していますが、完全な防止を保証するものではありません。
  </p>
</div>

<script>
// Load Chart.js from the primary CDN, falling back to a second CDN if the
// first one fails (blocked network, pruned version, transient outage).
// Exposes a promise so the rest of the page can wait for it without ever
// blocking the vote buttons on it.
function loadScript(src) {
  return new Promise(function (resolve, reject) {
    var s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = reject;
    document.head.appendChild(s);
  });
}
window.__chartJsReady = loadScript('${CHART_JS_PRIMARY_SRC}').catch(function () {
  return loadScript('${CHART_JS_FALLBACK_SRC}');
});
</script>
<script>
(function () {
  var btnSupport = document.getElementById('btn-support');
  var btnAgainst = document.getElementById('btn-against');
  var messageEl = document.getElementById('message');
  var summaryEl = document.getElementById('summary');
  var summarySupportEl = document.getElementById('summary-support');
  var summaryAgainstEl = document.getElementById('summary-against');
  var chart = null;

  function setButtonsDisabled(disabled) {
    btnSupport.disabled = disabled;
    btnAgainst.disabled = disabled;
  }

  function showMessage(text) {
    messageEl.textContent = text;
  }

  async function loadStatus() {
    try {
      var res = await fetch('/api/status');
      var data = await res.json();
      if (data.alreadyVoted) {
        setButtonsDisabled(true);
        showMessage('今週は投票済みです。ご協力ありがとうございました！（来週また投票できます）');
      }
    } catch (e) {
      // Non-fatal: voting still works, we just won't pre-disable the buttons.
    }
  }

  async function vote(choice) {
    setButtonsDisabled(true);
    showMessage('送信中…');
    try {
      var res = await fetch('/api/vote', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ choice: choice }),
      });
      var data = await res.json();
      if (res.status === 409) {
        showMessage('今週はすでに投票済みです。来週また投票できます。');
      } else if (data.ok) {
        showMessage('投票ありがとうございました！');
      } else {
        showMessage('エラーが発生しました。時間をおいて再度お試しください。');
        setButtonsDisabled(false);
      }
    } catch (e) {
      showMessage('通信エラーが発生しました。時間をおいて再度お試しください。');
      setButtonsDisabled(false);
    }
    loadResults();
  }

  async function loadResults() {
    try {
      var res = await fetch('/api/results');
      var data = await res.json();
      renderSummary(data.weeks, data.currentWeek);
      renderChart(data.weeks);
    } catch (e) {
      // Leave whatever was last rendered.
    }
  }

  function renderSummary(weeks, currentWeek) {
    var current = weeks.filter(function (w) { return w.week === currentWeek; })[0];
    if (!current) current = { support: 0, against: 0 };
    summarySupportEl.textContent = current.support;
    summaryAgainstEl.textContent = current.against;
    summaryEl.style.display = 'flex';
  }

  var chartLibFailed = false;

  async function renderChart(weeks) {
    if (chartLibFailed) return;

    // Wait for whichever CDN succeeded (or both to fail) before touching
    // window.Chart. Voting above never depends on this promise.
    try {
      await window.__chartJsReady;
    } catch (e) {
      chartLibFailed = true;
      var canvas = document.getElementById('chart');
      canvas.replaceWith(document.createTextNode('グラフ用ライブラリの読み込みに失敗しました（投票の受付には影響ありません）。'));
      return;
    }

    // "YYYY-MM-DD" -> "M/D" (no leading zeros), for compact axis labels.
    var labels = weeks.map(function (w) {
      var parts = w.weekStart.split('-');
      return Number(parts[1]) + '/' + Number(parts[2]);
    });
    var rateData = weeks.map(function (w) { return w.supportRate; });

    var ctx = document.getElementById('chart').getContext('2d');
    var config = {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: '支持率',
            data: rateData,
            borderColor: '#2e7d32',
            backgroundColor: 'rgba(46, 125, 50, 0.15)',
            fill: true,
            tension: 0.2,
            spanGaps: true,
            pointRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              // Line shows the support rate trend; the tooltip fills in the
              // underlying vote counts (n) for that week on demand.
              label: function (context) {
                var w = weeks[context.dataIndex];
                if (!w || w.total === 0) return '投票なし';
                return '支持率 ' + w.supportRate + '%（支持' + w.support + ' / 不支持' + w.against + '、計' + w.total + '票）';
              },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            ticks: { callback: function (v) { return v + '%'; } },
          },
        },
      },
    };

    if (chart) {
      chart.data = config.data;
      chart.options = config.options;
      chart.update();
    } else if (window.Chart) {
      chart = new window.Chart(ctx, config);
    }
  }

  btnSupport.addEventListener('click', function () { vote('support'); });
  btnAgainst.addEventListener('click', function () { vote('against'); });

  loadStatus();
  loadResults();
})();
</script>
</body>
</html>`;
}
