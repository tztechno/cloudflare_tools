// Takaichi Cabinet approval poll — single-file Cloudflare Worker.
//
// Routes:
//   GET  /             -> poll page (vote buttons + live weekly chart)
//   GET  /api/status   -> tells the caller whether they already voted this week
//   POST /api/vote     -> records a vote ({ choice: "support" | "against" })
//   GET  /api/results  -> weekly aggregated tallies, used to draw the chart
//
// Storage design (Workers KV, binding: POLL_KV):
//   Each vote is written to its own key: vote:<weekId>:<voterHash>
//   - weekId is an ISO-8601 week computed in JST (e.g. "2026-W38").
//     Because the week is baked into the key, a voter can vote again once a
//     new week starts without any TTL/expiry bookkeeping.
//   - voterHash fingerprints the visitor (IP + User-Agent, salted) so the
//     existence of the key IS the "already voted this week" check — no
//     separate counter to keep in sync, and no read-modify-write races.
//   - The vote's choice is stored both as the value and as put() metadata.
//     list() returns metadata without extra reads, so tallying a week is a
//     single (paginated) list() call instead of N individual get() calls.
//
// Known limitations (documented here on purpose):
//   - Workers KV is eventually consistent, so under very heavy concurrent
//     traffic a handful of duplicate votes from the same person are possible.
//     For a casual public opinion poll this tradeoff is fine.
//   - The IP+User-Agent fingerprint is not Sybil-proof (clearing cookies does
//     nothing here, but a new IP or a VPN does bypass it). It is meant to
//     deter casual repeat voting, not to be forensically strong.
//   - This is an informal, self-selected sample (X/Twitter followers who
//     click through), not a scientific poll. Say so on the page.

// Two independent CDNs are tried in order (see loadScriptWithFallback in the
// page's inline script below). If a visitor's network blocks one CDN, or a
// pinned version has been pruned from it, the page falls back to the other
// instead of silently failing to draw the chart. Voting itself never depends
// on this — only the chart rendering does.
const CHART_JS_PRIMARY_SRC = "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.5.1/chart.umd.min.js";
const CHART_JS_FALLBACK_SRC = "https://cdn.jsdelivr.net/npm/chart.js@4.5.1/dist/chart.umd.min.js";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/") {
      return new Response(renderHTML(), {
        headers: { "content-type": "text/html; charset=UTF-8" },
      });
    }

    if (request.method === "GET" && url.pathname === "/api/status") {
      return handleStatus(request, env);
    }

    if (request.method === "POST" && url.pathname === "/api/vote") {
      return handleVote(request, env);
    }

    if (request.method === "GET" && url.pathname === "/api/results") {
      return handleResults(env);
    }

    return new Response("Not Found", { status: 404 });
  },
};

// ---------------------------------------------------------------------------
// Week / fingerprint helpers
// ---------------------------------------------------------------------------

// Compute an ISO-8601 week id (Mon-Sun weeks, e.g. "2026-W38") as seen from
// Japan Standard Time. Workers always run with an internal UTC clock, so we
// shift the timestamp by +9h and then read it back with the UTC-* accessors
// as if that shifted instant were "local" JST time.
function getWeekId(now = new Date()) {
  const jst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
  const d = new Date(Date.UTC(jst.getUTCFullYear(), jst.getUTCMonth(), jst.getUTCDate()));

  // ISO week: shift to the Thursday of the same week, then count weeks
  // from the Thursday-anchored start of that ISO year.
  const dayNum = d.getUTCDay() || 7; // Sunday (0) -> 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);

  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

async function hashVoter(request, env) {
  const ip = request.headers.get("CF-Connecting-IP") || "unknown-ip";
  const ua = request.headers.get("User-Agent") || "unknown-ua";
  // VOTER_SALT is a secret set with `wrangler secret put VOTER_SALT`.
  // It just makes the fingerprint harder to precompute/guess; it is not
  // meant to be a strong anti-abuse measure on its own.
  const salt = env.VOTER_SALT || "change-me-please";
  const data = new TextEncoder().encode(`${ip}|${ua}|${salt}`);
  const digestBuf = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digestBuf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function jsonResponse(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=UTF-8" },
  });
}

// ---------------------------------------------------------------------------
// API handlers
// ---------------------------------------------------------------------------

async function handleStatus(request, env) {
  const weekId = getWeekId();
  const voterHash = await hashVoter(request, env);
  const existing = await env.POLL_KV.get(`vote:${weekId}:${voterHash}`);
  return jsonResponse({ weekId, alreadyVoted: existing !== null, choice: existing });
}

async function handleVote(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }

  const choice = body && body.choice;
  if (choice !== "support" && choice !== "against") {
    return jsonResponse({ error: "invalid_choice" }, 400);
  }

  const weekId = getWeekId();
  const voterHash = await hashVoter(request, env);
  const key = `vote:${weekId}:${voterHash}`;

  const existing = await env.POLL_KV.get(key);
  if (existing !== null) {
    return jsonResponse({ ok: false, alreadyVoted: true, weekId, choice: existing }, 409);
  }

  // Store the choice as both the value (human-readable in the KV dashboard)
  // and as metadata (so list() can tally without extra get() calls).
  await env.POLL_KV.put(key, choice, { metadata: { choice } });

  return jsonResponse({ ok: true, weekId, choice });
}

async function handleResults(env) {
  const weekly = {}; // weekId -> { support, against }
  let cursor;

  do {
    const page = await env.POLL_KV.list({ prefix: "vote:", cursor, limit: 1000 });

    for (const k of page.keys) {
      // Key shape: vote:<weekId>:<voterHash> — weekId itself has no colon.
      const parts = k.name.split(":");
      const weekId = parts[1];
      const choice = k.metadata && k.metadata.choice;

      if (!weekly[weekId]) weekly[weekId] = { support: 0, against: 0 };
      if (choice === "support") weekly[weekId].support++;
      else if (choice === "against") weekly[weekId].against++;
    }

    cursor = page.list_complete ? undefined : page.cursor;
  } while (cursor);

  const weeks = Object.keys(weekly)
    .sort()
    .map((week) => ({ week, ...weekly[week] }));

  return jsonResponse({ weeks, currentWeek: getWeekId() });
}

// ---------------------------------------------------------------------------
// HTML page (self-contained: inline CSS/JS, Chart.js loaded from cdnjs)
// ---------------------------------------------------------------------------

function renderHTML() {
  return `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>高市内閣 支持率アンケート</title>
<meta property="og:title" content="高市内閣 支持率アンケート">
<meta property="og:description" content="支持する／支持しないの2択で投票できます。1人1週間に1票までです。">
<meta property="og:type" content="website">
<style>
  :root {
    --support: #2e7d32;
    --against: #c62828;
    --bg: #f5f6f8;
    --card: #ffffff;
    --text: #1f2430;
    --muted: #6b7280;
    --border: #e3e5ea;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", "Yu Gothic", sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
    justify-content: center;
    padding: 24px 16px 64px;
  }
  .wrap { width: 100%; max-width: 640px; }
  h1 { font-size: 22px; margin: 0 0 4px; }
  .sub { color: var(--muted); font-size: 13px; margin: 0 0 20px; line-height: 1.6; }
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 16px;
  }
  .buttons { display: flex; gap: 12px; margin-top: 8px; }
  button.vote-btn {
    flex: 1;
    padding: 16px 8px;
    font-size: 16px;
    font-weight: 700;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    color: white;
    transition: opacity 0.15s;
  }
  button.vote-btn:disabled { opacity: 0.5; cursor: default; }
  button.support { background: var(--support); }
  button.against { background: var(--against); }
  #message {
    margin-top: 14px;
    font-size: 14px;
    min-height: 20px;
    color: var(--muted);
  }
  .summary { display: flex; gap: 16px; margin-top: 16px; }
  .summary .stat { flex: 1; text-align: center; }
  .summary .stat .num { font-size: 24px; font-weight: 700; }
  .summary .stat.support .num { color: var(--support); }
  .summary .stat.against .num { color: var(--against); }
  .summary .stat .label { font-size: 12px; color: var(--muted); }
  canvas { max-width: 100%; }
  .disclaimer { font-size: 12px; color: var(--muted); line-height: 1.7; margin-top: 24px; }
</style>
</head>
<body>
<div class="wrap">
  <h1>高市内閣 支持率アンケート</h1>
  <p class="sub">
    高市内閣を支持しますか？ 「支持する」「支持しない」のどちらかに投票してください。<br>
    ご投票は、お一人につき1週間に1回までです。
  </p>

  <div class="card">
    <div class="buttons">
      <button id="btn-support" class="vote-btn support">支持する</button>
      <button id="btn-against" class="vote-btn against">支持しない</button>
    </div>
    <div id="message"></div>
    <div class="summary" id="summary" style="display:none;">
      <div class="stat support">
        <div class="num" id="summary-support">-</div>
        <div class="label">支持する（今週）</div>
      </div>
      <div class="stat against">
        <div class="num" id="summary-against">-</div>
        <div class="label">支持しない（今週）</div>
      </div>
    </div>
  </div>

  <div class="card">
    <canvas id="chart" height="220"></canvas>
  </div>

  <p class="disclaimer">
    ※ このアンケートは個人が実施する非公式なインターネット投票です。回答者はSNS上の閲覧者に限られるため、
    統計的に社会全体の縮図とはなりません。参考情報としてご覧ください。<br>
    ※ 二重投票防止のため、簡易的な識別（IPアドレス等）を用いて1週間に1回までに制限していますが、完全な防止を保証するものではありません。
  </p>
</div>

<script>
// Load Chart.js from the primary CDN, falling back to a second CDN if the
// first one fails (blocked network, pruned version, transient outage).
// Exposes a promise so the rest of the page can wait for it without ever
// blocking the vote buttons on it.
function loadScript(src) {
  return new Promise(function (resolve, reject) {
    var s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = reject;
    document.head.appendChild(s);
  });
}
window.__chartJsReady = loadScript('${CHART_JS_PRIMARY_SRC}').catch(function () {
  return loadScript('${CHART_JS_FALLBACK_SRC}');
});
</script>
<script>
(function () {
  var btnSupport = document.getElementById('btn-support');
  var btnAgainst = document.getElementById('btn-against');
  var messageEl = document.getElementById('message');
  var summaryEl = document.getElementById('summary');
  var summarySupportEl = document.getElementById('summary-support');
  var summaryAgainstEl = document.getElementById('summary-against');
  var chart = null;

  function setButtonsDisabled(disabled) {
    btnSupport.disabled = disabled;
    btnAgainst.disabled = disabled;
  }

  function showMessage(text) {
    messageEl.textContent = text;
  }

  async function loadStatus() {
    try {
      var res = await fetch('/api/status');
      var data = await res.json();
      if (data.alreadyVoted) {
        setButtonsDisabled(true);
        showMessage('今週は投票済みです。ご協力ありがとうございました！（来週また投票できます）');
      }
    } catch (e) {
      // Non-fatal: voting still works, we just won't pre-disable the buttons.
    }
  }

  async function vote(choice) {
    setButtonsDisabled(true);
    showMessage('送信中…');
    try {
      var res = await fetch('/api/vote', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ choice: choice }),
      });
      var data = await res.json();
      if (res.status === 409) {
        showMessage('今週はすでに投票済みです。来週また投票できます。');
      } else if (data.ok) {
        showMessage('投票ありがとうございました！');
      } else {
        showMessage('エラーが発生しました。時間をおいて再度お試しください。');
        setButtonsDisabled(false);
      }
    } catch (e) {
      showMessage('通信エラーが発生しました。時間をおいて再度お試しください。');
      setButtonsDisabled(false);
    }
    loadResults();
  }

  async function loadResults() {
    try {
      var res = await fetch('/api/results');
      var data = await res.json();
      renderSummary(data.weeks, data.currentWeek);
      renderChart(data.weeks);
    } catch (e) {
      // Leave whatever was last rendered.
    }
  }

  function renderSummary(weeks, currentWeek) {
    var current = weeks.filter(function (w) { return w.week === currentWeek; })[0];
    if (!current) current = { support: 0, against: 0 };
    summarySupportEl.textContent = current.support;
    summaryAgainstEl.textContent = current.against;
    summaryEl.style.display = 'flex';
  }

  var chartLibFailed = false;

  async function renderChart(weeks) {
    if (chartLibFailed) return;

    // Wait for whichever CDN succeeded (or both to fail) before touching
    // window.Chart. Voting above never depends on this promise.
    try {
      await window.__chartJsReady;
    } catch (e) {
      chartLibFailed = true;
      var canvas = document.getElementById('chart');
      canvas.replaceWith(document.createTextNode('グラフ用ライブラリの読み込みに失敗しました（投票の受付には影響ありません）。'));
      return;
    }

    var labels = weeks.map(function (w) { return w.week; });
    var supportData = weeks.map(function (w) { return w.support; });
    var againstData = weeks.map(function (w) { return w.against; });

    var ctx = document.getElementById('chart').getContext('2d');
    var config = {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          { label: '支持する', data: supportData, backgroundColor: '#2e7d32' },
          { label: '支持しない', data: againstData, backgroundColor: '#c62828' },
        ],
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
      },
    };

    if (chart) {
      chart.data = config.data;
      chart.update();
    } else if (window.Chart) {
      chart = new window.Chart(ctx, config);
    }
  }

  btnSupport.addEventListener('click', function () { vote('support'); });
  btnAgainst.addEventListener('click', function () { vote('against'); });

  loadStatus();
  loadResults();
})();
</script>
</body>
</html>`;
}
