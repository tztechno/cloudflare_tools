// Cloudflare Worker: a "study room" (jishushitsu) presence app.
// - Serves the frontend (HTML/CSS/JS) at "/"
// - Serves a REST API at "/api/room" backed by Workers KV
// - The room only accepts new entries between 9:00 and 17:00 JST.
// - Each entry is stored with a KV TTL that expires exactly at 17:00 JST,
//   so everyone is automatically "kicked out" at closing time with no
//   separate cron job needed.

const KV_PREFIX = "room:";
const OPEN_HOUR = 9; // JST, inclusive
const CLOSE_HOUR = 17; // JST, exclusive
const MIN_TTL_SECONDS = 60; // Cloudflare KV requires expirationTtl >= 60

function jsonResponse(data, init = {}) {
  return new Response(JSON.stringify(data), {
    ...init,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...(init.headers || {}),
    },
  });
}

function badRequest(message) {
  return jsonResponse({ error: message }, { status: 400 });
}

function forbidden(message) {
  return jsonResponse({ error: message }, { status: 403 });
}

// --- JST time helpers ---
// Workers always run in UTC, so we shift by +9 hours and read the UTC*
// getters on the shifted Date to get JST wall-clock values.

function jstNow() {
  return new Date(Date.now() + 9 * 60 * 60 * 1000);
}

function isRoomOpen(jst = jstNow()) {
  const h = jst.getUTCHours();
  return h >= OPEN_HOUR && h < CLOSE_HOUR;
}

function secondsUntilClose(jst = jstNow()) {
  const close = new Date(
    Date.UTC(jst.getUTCFullYear(), jst.getUTCMonth(), jst.getUTCDate(), CLOSE_HOUR, 0, 0, 0)
  );
  const diffMs = close.getTime() - jst.getTime();
  return Math.max(MIN_TTL_SECONDS, Math.floor(diffMs / 1000));
}

function jstTimeLabel(jst = jstNow()) {
  const hh = String(jst.getUTCHours()).padStart(2, "0");
  const mm = String(jst.getUTCMinutes()).padStart(2, "0");
  return `${hh}:${mm}`;
}

// --- KV data access ---

async function listRoom(env) {
  const people = [];
  let cursor;
  do {
    const page = await env.ROOM_KV.list({ prefix: KV_PREFIX, cursor });
    const values = await Promise.all(page.keys.map((k) => env.ROOM_KV.get(k.name, "json")));
    for (const v of values) {
      if (v) people.push(v);
    }
    cursor = page.cursor;
    if (page.list_complete) break;
  } while (cursor);

  people.sort((a, b) => (a.enteredAt < b.enteredAt ? -1 : 1));
  return people;
}

async function enterRoom(env, name) {
  const jst = jstNow();
  if (!isRoomOpen(jst)) {
    return { error: `受付時間外です（${OPEN_HOUR}:00〜${CLOSE_HOUR}:00のみ入室できます）` };
  }
  const id = crypto.randomUUID();
  const entry = {
    id,
    name,
    enteredAt: new Date().toISOString(),
  };
  const ttl = secondsUntilClose(jst);
  await env.ROOM_KV.put(KV_PREFIX + id, JSON.stringify(entry), { expirationTtl: ttl });
  return { entry };
}

async function leaveRoom(env, id) {
  await env.ROOM_KV.delete(KV_PREFIX + id);
}

// --- API router ---

async function handleApi(request, env, url) {
  const parts = url.pathname.split("/").filter(Boolean); // ["api", "room", maybe "enter"/"leave"]
  const action = parts[2];

  if (request.method === "GET" && !action) {
    const jst = jstNow();
    const people = await listRoom(env);
    return jsonResponse({
      isOpen: isRoomOpen(jst),
      currentTime: jstTimeLabel(jst),
      openHour: OPEN_HOUR,
      closeHour: CLOSE_HOUR,
      people,
    });
  }

  if (request.method === "POST" && action === "enter") {
    let body;
    try {
      body = await request.json();
    } catch {
      return badRequest("Invalid JSON body");
    }
    const name = typeof body?.name === "string" ? body.name.trim() : "";
    if (!name) return badRequest("`name` is required");
    if (name.length > 40) return badRequest("`name` is too long");

    const result = await enterRoom(env, name);
    if (result.error) return forbidden(result.error);
    return jsonResponse(result.entry, { status: 201 });
  }

  if (request.method === "POST" && action === "leave") {
    let body;
    try {
      body = await request.json();
    } catch {
      return badRequest("Invalid JSON body");
    }
    const id = typeof body?.id === "string" ? body.id : "";
    if (!id) return badRequest("`id` is required");
    await leaveRoom(env, id);
    return new Response(null, { status: 204 });
  }

  return jsonResponse({ error: "Not found" }, { status: 404 });
}

// --- Frontend (single self-contained HTML page) ---

const HTML_PAGE = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>自習室</title>
<style>
  :root {
    --bg: #f5f6fa;
    --card: #ffffff;
    --text: #1f2430;
    --muted: #8a90a2;
    --accent: #4f6df5;
    --accent-hover: #3d59d6;
    --border: #e4e6ef;
    --open: #2fae66;
    --closed: #e5484d;
  }
  @media (prefers-color-scheme: dark) {
    :root {
      --bg: #14161f;
      --card: #1c1f2b;
      --text: #eceef5;
      --muted: #8890a6;
      --accent: #6d86ff;
      --accent-hover: #859bff;
      --border: #2b2f3f;
      --open: #4bd486;
      --closed: #ff6b6f;
    }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    min-height: 100vh;
    background: var(--bg);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Hiragino Sans, sans-serif;
    display: flex;
    justify-content: center;
    padding: 40px 16px;
  }
  main {
    width: 100%;
    max-width: 520px;
  }
  h1 {
    font-size: 22px;
    margin: 0 0 4px;
  }
  .status-line {
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--muted);
    font-size: 14px;
    margin-bottom: 20px;
  }
  .status-dot {
    width: 9px;
    height: 9px;
    border-radius: 50%;
    display: inline-block;
  }
  .status-dot.open { background: var(--open); }
  .status-dot.closed { background: var(--closed); }
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
  }
  form {
    display: flex;
    gap: 8px;
  }
  input[type="text"] {
    flex: 1;
    padding: 12px 14px;
    border-radius: 10px;
    border: 1px solid var(--border);
    background: var(--bg);
    color: var(--text);
    font-size: 15px;
  }
  input[type="text"]:focus {
    outline: 2px solid var(--accent);
    outline-offset: -1px;
  }
  button {
    border: none;
    border-radius: 10px;
    background: var(--accent);
    color: #fff;
    font-size: 15px;
    padding: 12px 18px;
    cursor: pointer;
  }
  button:hover { background: var(--accent-hover); }
  button:disabled {
    background: var(--muted);
    cursor: not-allowed;
  }
  .leave-btn {
    width: 100%;
    background: var(--closed);
  }
  .leave-btn:hover { background: #c93f43; }
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  li {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 12px 14px;
    font-size: 15px;
  }
  li .elapsed {
    color: var(--muted);
    font-size: 13px;
  }
  .empty, .closed-message {
    color: var(--muted);
    font-size: 14px;
    text-align: center;
    padding: 24px 0;
  }
  .error {
    color: var(--closed);
    font-size: 13px;
    margin-top: 8px;
    display: none;
  }
  h2 {
    font-size: 15px;
    color: var(--muted);
    margin: 0 0 12px;
    font-weight: 600;
  }
</style>
</head>
<body>
<main>
  <h1>自習室</h1>
  <div class="status-line">
    <span class="status-dot" id="status-dot"></span>
    <span id="status-text">読み込み中...</span>
  </div>

  <div class="card" id="entry-card">
    <form id="enter-form">
      <input type="text" id="name-input" placeholder="お名前（ニックネームでOK）" autocomplete="off" maxlength="40" required />
      <button type="submit" id="enter-btn">入室する</button>
    </form>
    <div class="error" id="error"></div>
  </div>

  <div class="card" id="inside-card" style="display:none;">
    <p id="inside-text"></p>
    <button class="leave-btn" id="leave-btn">退室する</button>
  </div>

  <h2 id="list-heading">今、自習室にいる人</h2>
  <ul id="list"></ul>
  <div class="empty" id="empty" style="display:none;">まだ誰もいません。</div>
</main>

<script>
  // All presence data lives in Cloudflare Workers KV via /api/room.
  // "myId" (this browser's current entry id) is kept in localStorage so a
  // page refresh doesn't lose track of your own entry.
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');
  const entryCard = document.getElementById('entry-card');
  const insideCard = document.getElementById('inside-card');
  const insideText = document.getElementById('inside-text');
  const enterForm = document.getElementById('enter-form');
  const nameInput = document.getElementById('name-input');
  const enterBtn = document.getElementById('enter-btn');
  const leaveBtn = document.getElementById('leave-btn');
  const errorEl = document.getElementById('error');
  const listEl = document.getElementById('list');
  const emptyEl = document.getElementById('empty');
  const listHeading = document.getElementById('list-heading');

  function getMyId() {
    try { return localStorage.getItem('myId'); } catch (_) { return null; }
  }
  function setMyId(id) {
    try {
      if (id) localStorage.setItem('myId', id);
      else localStorage.removeItem('myId');
    } catch (_) {}
  }
  function getMyName() {
    try { return localStorage.getItem('myName') || ''; } catch (_) { return ''; }
  }
  function setMyName(name) {
    try { localStorage.setItem('myName', name); } catch (_) {}
  }

  function showError(message) {
    errorEl.textContent = message;
    errorEl.style.display = 'block';
  }
  function clearError() {
    errorEl.style.display = 'none';
  }

  function formatElapsed(enteredAt) {
    const ms = Date.now() - new Date(enteredAt).getTime();
    const totalMinutes = Math.max(0, Math.floor(ms / 60000));
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    if (h > 0) return h + '時間' + m + '分';
    return m + '分';
  }

  async function api(path, options) {
    const res = await fetch(path, options);
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const body = await res.json();
        if (body && body.error) detail = body.error;
      } catch (_) {}
      throw new Error(detail);
    }
    if (res.status === 204) return null;
    return res.json();
  }

  function render(data) {
    const isOpen = data.isOpen;
    statusDot.className = 'status-dot ' + (isOpen ? 'open' : 'closed');
    statusText.textContent =
      '現在 ' + data.currentTime + ' — ' +
      (isOpen ? '受付中（' : '受付時間外（') +
      data.openHour + ':00〜' + data.closeHour + ':00）';

    const myId = getMyId();
    const mine = myId ? data.people.find((p) => p.id === myId) : null;

    if (mine) {
      entryCard.style.display = 'none';
      insideCard.style.display = 'block';
      insideText.textContent = mine.name + ' さんとして入室中（' + formatElapsed(mine.enteredAt) + '経過）';
    } else {
      // Not currently inside (never entered, or TTL expired at closing time).
      setMyId(null);
      insideCard.style.display = 'none';
      entryCard.style.display = 'block';
      enterBtn.disabled = !isOpen;
      nameInput.disabled = !isOpen;
      if (!isOpen) {
        clearError();
      }
    }

    listHeading.textContent = '今、自習室にいる人（' + data.people.length + '人）';
    listEl.innerHTML = '';
    emptyEl.style.display = data.people.length ? 'none' : 'block';
    for (const p of data.people) {
      const li = document.createElement('li');
      const nameSpan = document.createElement('span');
      nameSpan.textContent = p.name + (p.id === myId ? '（あなた）' : '');
      const elapsedSpan = document.createElement('span');
      elapsedSpan.className = 'elapsed';
      elapsedSpan.textContent = formatElapsed(p.enteredAt);
      li.append(nameSpan, elapsedSpan);
      listEl.appendChild(li);
    }
  }

  async function refresh() {
    try {
      const data = await api('/api/room');
      render(data);
    } catch (err) {
      statusText.textContent = '読み込みに失敗しました: ' + err.message;
    }
  }

  enterForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = nameInput.value.trim();
    if (!name) return;
    try {
      const entry = await api('/api/room/enter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      clearError();
      setMyId(entry.id);
      setMyName(name);
      await refresh();
    } catch (err) {
      showError(err.message);
    }
  });

  leaveBtn.addEventListener('click', async () => {
    const myId = getMyId();
    if (!myId) return;
    try {
      await api('/api/room/leave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: myId }),
      });
    } catch (_) {
      // Even if the delete failed (e.g. already expired), clear local state.
    }
    setMyId(null);
    await refresh();
  });

  // Pre-fill the name field with whatever was used last time.
  nameInput.value = getMyName();

  refresh();
  setInterval(refresh, 5000); // poll every 5 seconds
</script>
</body>
</html>`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/api/")) {
      return handleApi(request, env, url);
    }

    if (url.pathname === "/" || url.pathname === "/index.html") {
      return new Response(HTML_PAGE, {
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    return new Response("Not found", { status: 404 });
  },
};
