# cf-todo

A TODO list app that runs entirely on Cloudflare: a single Worker serves both
the frontend page and a REST API, with all data read from and written to
Cloudflare Workers KV.

## Stack

- **Runtime**: Cloudflare Workers (`src/index.js`, no build step, no framework)
- **Storage**: Workers KV — each todo is stored as its own key (`todo:<uuid>`)
- **Frontend**: a single embedded HTML page (vanilla JS, no dependencies) served at `/`

## API

| Method | Path              | Body                          | Description            |
|--------|-------------------|--------------------------------|-------------------------|
| GET    | `/api/todos`       | –                               | List all todos          |
| POST   | `/api/todos`       | `{ "text": "..." }`             | Create a todo           |
| PATCH  | `/api/todos/:id`   | `{ "text"?, "completed"? }`     | Update a todo           |
| DELETE | `/api/todos/:id`   | –                               | Delete a todo           |

A todo looks like:

```json
{
  "id": "uuid",
  "text": "Buy milk",
  "completed": false,
  "createdAt": "2026-09-17T01:51:33.977Z",
  "updatedAt": "2026-09-17T01:51:33.977Z"
}
```

## Setup

Requires a Cloudflare account and Node.js. All commands below run from this
directory.

```bash
npm install
```

### 1. Log in to Cloudflare

```bash
npx wrangler login
```

### 2. Create the KV namespace

```bash
npx wrangler kv namespace create TODO_KV
npx wrangler kv namespace create TODO_KV --preview
```

Each command prints an `id`. Paste them into `wrangler.toml`:

```toml
[[kv_namespaces]]
binding = "TODO_KV"
id = "<id from the first command>"
preview_id = "<id from the --preview command>"
```

### 3. Run locally

```bash
npm run dev
```

This starts the Worker at `http://localhost:8787` with a local (in-memory)
KV emulation — no live Cloudflare resources are touched. Open the URL in a
browser to use the TODO list, or hit the API directly, e.g.:

```bash
curl -X POST http://localhost:8787/api/todos \
  -H 'Content-Type: application/json' \
  -d '{"text":"Buy milk"}'
```

### 4. Deploy

```bash
npm run deploy
```

Wrangler prints the deployed URL (`https://cf-todo.<your-subdomain>.workers.dev`
by default). Open it — the same page and API now run against your real
Cloudflare KV namespace.

## Notes / possible extensions

- This app has no authentication — anyone with the URL can read/write the
  list. Add Cloudflare Access, or a shared-secret header checked in
  `handleApi`, if you need to restrict it.
- KV writes are eventually consistent across Cloudflare's edge (typically
  within a few seconds), which is fine for a personal TODO list but worth
  knowing if you open the same list from two devices at once.
- Swapping storage to D1 (SQL) or Durable Objects later only requires
  rewriting the functions in the "KV data access helpers" section of
  `src/index.js` — the API and frontend don't need to change.
