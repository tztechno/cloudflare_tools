// Cloudflare Worker: a single-file TODO app.
// - Serves the frontend (HTML/CSS/JS) at "/"
// - Serves a REST API at "/api/todos" backed by Workers KV
//
// Data model stored in KV:
//   key:   todo:<uuid>
//   value: { id, text, completed, createdAt, updatedAt }  (JSON)

const KV_PREFIX = "todo:";

function jsonResponse(data, init = {}) {
  return new Response(JSON.stringify(data), {
    ...init,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...(init.headers || {}),
    },
  });
}

function notFound(message = "Not found") {
  return jsonResponse({ error: message }, { status: 404 });
}

function badRequest(message = "Bad request") {
  return jsonResponse({ error: message }, { status: 400 });
}

// --- KV data access helpers ---

async function listTodos(env) {
  const todos = [];
  let cursor;
  // Paginate through all keys with the todo: prefix.
  do {
    const page = await env.TODO_KV.list({ prefix: KV_PREFIX, cursor });
    const values = await Promise.all(
      page.keys.map((k) => env.TODO_KV.get(k.name, "json"))
    );
    for (const v of values) {
      if (v) todos.push(v);
    }
    cursor = page.cursor;
    if (page.list_complete) break;
  } while (cursor);

  todos.sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1));
  return todos;
}

async function getTodo(env, id) {
  return env.TODO_KV.get(KV_PREFIX + id, "json");
}

async function createTodo(env, text) {
  const now = new Date().toISOString();
  const todo = {
    id: crypto.randomUUID(),
    text,
    completed: false,
    createdAt: now,
    updatedAt: now,
  };
  await env.TODO_KV.put(KV_PREFIX + todo.id, JSON.stringify(todo));
  return todo;
}

async function updateTodo(env, id, patch) {
  const existing = await getTodo(env, id);
  if (!existing) return null;

  const updated = {
    ...existing,
    ...("text" in patch ? { text: patch.text } : {}),
    ...("completed" in patch ? { completed: !!patch.completed } : {}),
    id: existing.id,
    createdAt: existing.createdAt,
    updatedAt: new Date().toISOString(),
  };
  await env.TODO_KV.put(KV_PREFIX + id, JSON.stringify(updated));
  return updated;
}

async function deleteTodo(env, id) {
  const existing = await getTodo(env, id);
  if (!existing) return false;
  await env.TODO_KV.delete(KV_PREFIX + id);
  return true;
}

// --- API router ---

async function handleApi(request, env, url) {
  const parts = url.pathname.split("/").filter(Boolean); // ["api", "todos", maybe id]
  const id = parts[2];

  if (request.method === "GET" && !id) {
    const todos = await listTodos(env);
    return jsonResponse(todos);
  }

  if (request.method === "POST" && !id) {
    let body;
    try {
      body = await request.json();
    } catch {
      return badRequest("Invalid JSON body");
    }
    if (!body || typeof body.text !== "string" || !body.text.trim()) {
      return badRequest("`text` is required");
    }
    const todo = await createTodo(env, body.text.trim());
    return jsonResponse(todo, { status: 201 });
  }

  if (request.method === "PATCH" && id) {
    let body;
    try {
      body = await request.json();
    } catch {
      return badRequest("Invalid JSON body");
    }
    const updated = await updateTodo(env, id, body || {});
    if (!updated) return notFound("Todo not found");
    return jsonResponse(updated);
  }

  if (request.method === "DELETE" && id) {
    const ok = await deleteTodo(env, id);
    if (!ok) return notFound("Todo not found");
    return new Response(null, { status: 204 });
  }

  return notFound();
}

// --- Frontend (single self-contained HTML page) ---

const HTML_PAGE = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TODO List</title>
<style>
  :root {
    --bg: #f5f6fa;
    --card: #ffffff;
    --text: #1f2430;
    --muted: #8a90a2;
    --accent: #4f6df5;
    --accent-hover: #3d59d6;
    --border: #e4e6ef;
    --done: #b7bbc9;
    --danger: #e5484d;
  }
  @media (prefers-color-scheme: dark) {
    :root {
      --bg: #14161f;
      --card: #1c1f2b;
      --text: #eceef5;
      --muted: #8890a6;
      --accent: #6d86ff;
      --accent-hover: #859bff;
      --border: #2b2f3f;
      --done: #565b6e;
      --danger: #ff6b6f;
    }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    min-height: 100vh;
    background: var(--bg);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Hiragino Sans, sans-serif;
    display: flex;
    justify-content: center;
    padding: 40px 16px;
  }
  main {
    width: 100%;
    max-width: 520px;
  }
  h1 {
    font-size: 22px;
    margin: 0 0 20px;
  }
  form {
    display: flex;
    gap: 8px;
    margin-bottom: 20px;
  }
  input[type="text"] {
    flex: 1;
    padding: 12px 14px;
    border-radius: 10px;
    border: 1px solid var(--border);
    background: var(--card);
    color: var(--text);
    font-size: 15px;
  }
  input[type="text"]:focus {
    outline: 2px solid var(--accent);
    outline-offset: -1px;
  }
  button {
    border: none;
    border-radius: 10px;
    background: var(--accent);
    color: #fff;
    font-size: 15px;
    padding: 12px 18px;
    cursor: pointer;
  }
  button:hover { background: var(--accent-hover); }
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  li {
    display: flex;
    align-items: center;
    gap: 12px;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 12px 14px;
  }
  li .text {
    flex: 1;
    font-size: 15px;
    word-break: break-word;
  }
  li.completed .text {
    color: var(--done);
    text-decoration: line-through;
  }
  li input[type="checkbox"] {
    width: 18px;
    height: 18px;
    accent-color: var(--accent);
    cursor: pointer;
  }
  li .delete-btn {
    background: none;
    color: var(--muted);
    padding: 4px 8px;
    font-size: 13px;
  }
  li .delete-btn:hover { color: var(--danger); }
  .empty {
    color: var(--muted);
    font-size: 14px;
    text-align: center;
    padding: 24px 0;
  }
  .error {
    color: var(--danger);
    font-size: 13px;
    margin-bottom: 12px;
    display: none;
  }
</style>
</head>
<body>
<main>
  <h1>TODO List</h1>
  <div class="error" id="error"></div>
  <form id="add-form">
    <input type="text" id="new-todo" placeholder="New task..." autocomplete="off" required />
    <button type="submit">Add</button>
  </form>
  <ul id="list"></ul>
  <div class="empty" id="empty" style="display:none;">No tasks yet.</div>
</main>

<script>
  // All data is stored in Cloudflare Workers KV via the /api/todos endpoint.
  const listEl = document.getElementById('list');
  const emptyEl = document.getElementById('empty');
  const errorEl = document.getElementById('error');
  const formEl = document.getElementById('add-form');
  const inputEl = document.getElementById('new-todo');

  function showError(message) {
    errorEl.textContent = message;
    errorEl.style.display = 'block';
  }

  function clearError() {
    errorEl.style.display = 'none';
  }

  async function api(path, options) {
    const res = await fetch(path, options);
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const body = await res.json();
        if (body && body.error) detail = body.error;
      } catch (_) {}
      throw new Error(detail);
    }
    if (res.status === 204) return null;
    return res.json();
  }

  function renderTodos(todos) {
    listEl.innerHTML = '';
    emptyEl.style.display = todos.length ? 'none' : 'block';

    for (const todo of todos) {
      const li = document.createElement('li');
      li.className = todo.completed ? 'completed' : '';
      li.dataset.id = todo.id;

      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = todo.completed;
      checkbox.addEventListener('change', () => toggleTodo(todo.id, checkbox.checked));

      const span = document.createElement('span');
      span.className = 'text';
      span.textContent = todo.text;

      const delBtn = document.createElement('button');
      delBtn.className = 'delete-btn';
      delBtn.textContent = 'Delete';
      delBtn.addEventListener('click', () => deleteTodo(todo.id));

      li.append(checkbox, span, delBtn);
      listEl.appendChild(li);
    }
  }

  async function loadTodos() {
    try {
      const todos = await api('/api/todos');
      clearError();
      renderTodos(todos);
    } catch (err) {
      showError('Failed to load todos: ' + err.message);
    }
  }

  async function addTodo(text) {
    try {
      await api('/api/todos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      clearError();
      await loadTodos();
    } catch (err) {
      showError('Failed to add todo: ' + err.message);
    }
  }

  async function toggleTodo(id, completed) {
    try {
      await api('/api/todos/' + id, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed }),
      });
      clearError();
      await loadTodos();
    } catch (err) {
      showError('Failed to update todo: ' + err.message);
    }
  }

  async function deleteTodo(id) {
    try {
      await api('/api/todos/' + id, { method: 'DELETE' });
      clearError();
      await loadTodos();
    } catch (err) {
      showError('Failed to delete todo: ' + err.message);
    }
  }

  formEl.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = inputEl.value.trim();
    if (!text) return;
    inputEl.value = '';
    addTodo(text);
  });

  loadTodos();
</script>
</body>
</html>`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/api/")) {
      return handleApi(request, env, url);
    }

    if (url.pathname === "/" || url.pathname === "/index.html") {
      return new Response(HTML_PAGE, {
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    return notFound();
  },
};
